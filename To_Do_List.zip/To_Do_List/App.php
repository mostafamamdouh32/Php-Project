<?php
require_once 'classes/request.php';
require_once 'classes/Session.php';
require_once 'classes/Validation/validation.php';
use classess\Req\Request;
use classess\Ses\Session;
use classess\validation\validation;
$request = new Request;
$session= new session;
$validation=new validation;


