<?php
namespace classess\validation;
interface Validator{
    public function check($key , $value);
}